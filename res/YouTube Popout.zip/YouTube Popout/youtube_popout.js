var player, timeout;

function tryToEnableYouTubePopoutButton() {
  if (timeout)
    clearTimeout(timeout);
  else 
    timeout = null;

  if (player.getPlayerState) console.log(player.getPlayerState())

  if (!player.getPlayerState)
    timeout = setTimeout(tryToEnableYouTubePopoutButton,500);
  else 
    jQuery('#YouTubePopoutButton').removeAttr('disabled');
}

function addYouTubePopoutButton() {
  var jp = jQuery(player);
  var offset = jp.offset();
  var button = jQuery(
    '<button id="YouTubePopoutButton" class="yt-uix-button">'
    + '<span class="yt-uix-button-content">Popout</span>'
    + '</button>'
  );
  button.attr('disabled','disabled');
  jQuery('body').append(button);

  button.css({
    'position': 'absolute',
    'top': offset.top - button.height() - 5 + 'px',
    'left': offset.left + jp.width() - button.width() - 10 + 'px',
    'zIndex': 99999
  });

  button.click(function() {
    player = jQuery('#movie_player')[0];

    player.pauseVideo();

    chrome.extension.sendRequest({set: true, html: player.getVideoEmbedCode(), title: document.title});

    return false;
  });

}

jQuery.noConflict();
jQuery(document).ready(function() {
  player = jQuery('#movie_player')[0];
  addYouTubePopoutButton();
  tryToEnableYouTubePopoutButton();
});
